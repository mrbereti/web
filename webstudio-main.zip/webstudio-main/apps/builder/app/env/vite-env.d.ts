interface ImportMetaEnv {
  readonly GITHUB_REF_NAME: string | undefined;
  readonly GITHUB_SHA: string | undefined;
}
