export {
  KeyboardShortcutsDialog,
  openKeyboardShortcutsDialog,
} from "./keyboard-shortcuts-dialog";
