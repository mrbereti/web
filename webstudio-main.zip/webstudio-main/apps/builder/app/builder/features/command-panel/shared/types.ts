export type BaseOption = {
  terms: string[];
  type: string;
};
