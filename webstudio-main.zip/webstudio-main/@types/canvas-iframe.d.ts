declare namespace React {
  interface IframeHTMLAttributes {
    credentialless?: "true";
  }
}
